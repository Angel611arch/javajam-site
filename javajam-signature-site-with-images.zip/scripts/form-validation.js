
function cap(v){v=v.trim();return v?v[0].toUpperCase()+v.slice(1).toLowerCase():""}
document.addEventListener("DOMContentLoaded",()=>{
 const f=document.getElementById("contactForm");
 if(!f)return;
 f.addEventListener("submit",e=>{
  e.preventDefault();
  f.firstName.value=cap(f.firstName.value);
  f.lastName.value=cap(f.lastName.value);
  f.city.value=cap(f.city.value);
  document.getElementById("status").textContent="Form validated successfully (demo).";
 });
});
